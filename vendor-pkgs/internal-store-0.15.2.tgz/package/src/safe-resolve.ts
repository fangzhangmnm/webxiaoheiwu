// ⚠ 使用前必读 README.md + CONTEXT.md。app 不直接 import——经 createStore。
//
// safe-resolve（深模块）—— **永不丢字节**地化解本地↔云端分歧。单一职责 = 那条不可重排的顺序：
//   备份先于覆盖(A4/A10) · 采纳前校验真容器(N2,挡 captive-portal HTML) · 采纳后置 etag(R1) ·
//   lost-response 自愈(B5) · 冲突派发(keepMine/takeCloud/cancel)。
// 吃：cloud(pull/weakOverride) + local(backup/save) + local-head(markSynced 落地谱系)。
import { toU8, bytesEqual } from "./substrate.ts";
import type { Bytes } from "./substrate.ts";
import { reportStoreError } from "./error-handling.ts";   // 全接但分级：静默 swallow 也 funnel（不改控制流）
import type { CloudSync, LocalCache } from "./types.ts";
import type { LocalHead } from "./local-head.ts";

/** 冲突派发的选择串（keepMine / takeCloud / cancel）。 */
export type ResolveChoice = "keepMine" | "takeCloud" | "cancel";

export type SafePullResult =
  | { ok: true; backupName?: string }
  | { ok: false; reason: string; backupName?: string; error?: unknown };

import type { AdoptFn } from "./types.ts";

export interface SafeResolveCfg {
  cloud: Pick<CloudSync, "pull" | "weakOverride">;
  local: Pick<LocalCache, "backup" | "save">;
  head: Pick<LocalHead, "isDirtyAnywhere" | "markSynced" | "seenBase"> & Partial<Pick<LocalHead, "editCount">>;
  /** 同名串行链（substrate.serialize）。用户保存的本地写在这条链上；「核对 + 覆盖本地 + 提交谱系」也必须在这条链上，
   *  否则两次写谁后落盘说不准（0.15.2）。不给 = 不串行（单元测试的替身场景）。 */
  serialize?: <T>(name: string, fn: () => Promise<T>) => Promise<T>;
  localDirty?: () => boolean;                                  // 活动 doc 未落盘（substrate.edits.localDirty）
  // N2 采纳云字节前的校验闸——**必传，无 noop 默认**（store 格式盲，逻辑 app 给）。验的是**解密后的明文**
  //   （库对加密透明）：app 看到的是真明文文档，不是密文容器。挡 captive-portal HTML / 损坏云副本覆盖好本地。
  validateAdopt: (plain: Blob) => boolean | Promise<boolean>;
  unseal?: (name: string, blob: Blob) => Promise<Blob | null>; // adopt 前解壳（seal 提供）：返明文；加密但锁定 → null。默认明文原样。
  onReplacing?: (on: boolean) => void;                         // N10：换内容临界段 gate（input 起笔门读它降级）
  looksEncrypted?: (bytes: Blob | Bytes) => Promise<boolean>;  // 是否加密容器（weakOverride 扩展名 + 锁定时退验封套）
}

// 化解冲突的终态（联合类型，非裸 string）：resolved=已化解 · unresolved=没化解（字节仍在 .backup）· cancelled=用户取消（留 dirty）
export type ResolveStatus = "resolved" | "unresolved" | "cancelled";

export interface ResolveConflictResult { status: ResolveStatus; resolution?: string; reason?: string; backupName?: string; backedUp?: string | null }

export interface SafeResolve {
  /** inChain：调用方已经站在这个名字的串行链上（推送撞冲突后的 resolveConflict）→ 临界段直接跑，不再排队（否则自己等自己）。 */
  safePull(name: string, opts?: { adopt?: AdoptFn; forceBackup?: boolean; inChain?: boolean }): Promise<SafePullResult>;
  tryHeal(name: string, bytes: Bytes): Promise<boolean>;
  weakOverride(name: string, bytes: Bytes): Promise<{ backedUp: string | null; deferred?: boolean }>;
  resolveConflict(name: string, choice: ResolveChoice, ctx?: { bytes?: Bytes | null; adopt?: AdoptFn; inChain?: boolean }): Promise<ResolveConflictResult>;
}

export function createSafeResolve(cfg: SafeResolveCfg): SafeResolve {
  const {
    cloud, local, head,
    localDirty = () => false,
    validateAdopt,
    unseal = (_n, blob) => Promise.resolve(blob),
    onReplacing = () => {},
    looksEncrypted = () => Promise.resolve(false),
    serialize = (_n, fn) => fn(),
  } = cfg;
  const editCount = (name: string): number => head.editCount?.(name) ?? 0;

  // 安全拉取覆盖：先 backup（dirty 才备；失败即 abort，绝不 pull/覆盖）→ 拉 → 校验 → 覆盖 → 采纳后置 etag → adopt。
  // 持久态只在原子点改；强退任一 await 点可重入。
  // forceBackup（2026-08-25 user 拍板，案卷 20260825-cloud-override-adopt-noop-case.md §5 前提）：
  //   takeCloud 是「文件版本模型」的换世界线，不是 workspace 操作——被换掉的当前世界线**无条件**先进 .backup。
  //   （clean-skip 的「本地可从云重取」论据在 takeCloud 场景恰恰失效过：本地随后覆写云端时，云端那版就不再兜底。）
  //   freshness 的静默快进（clean fast-forward）不传它——ADR-0016 的不 spam .backup 决策不动。
  //
  // 0.15.2「途中又保存」守卫（WXHW 两台设备端到端测试 2026-09-29 顺藤摸到；user「同步库的一个洞 修」）：
  //   下载要花时间。开头判过一次脏之后，用户的 save() 可能在下载途中落了新字节——以前下载完照样覆盖并 markSynced，
  //   那份字节既不在本地也不在备份箱，dirty 还被清掉。现在：开头记下这个文件的保存计数 e0；下载、校验完之后进**临界段**
  //   （站在同名串行链上，和用户保存的本地写互斥）：
  //     ① 计数变了 = 途中保存过。静默快进（没人要求换世界线）→ **作罢**，本地分毫不动，dirty 照旧，之后推送自会撞冲突面；
  //        用户点了「云端覆盖本地」（forceBackup）→ 把途中保存的那一份**再备份一次**，然后照用户的意思覆盖。
  //     ② 覆盖本地。
  //     ③ 再看一眼计数：覆盖的那一下又保存了（它的本地写排在我们后面，马上会落成最终字节）→ **不提交谱系**：
  //        本地最终是「旧世界 + 新改动」，dirty 和 parent 都还是 recordEdit 留下的样子（parent = 旧 base），
  //        下次推送 If-Match 旧 etag → 412 → 冲突面。提交了才是事故：谱系指向云端新版、标成干净，下次推送静默盖掉云端赢家。
  async function safePull(name: string, { adopt, forceBackup = false, inChain = false }: { adopt?: AdoptFn; forceBackup?: boolean; inChain?: boolean } = {}): Promise<SafePullResult> {
    onReplacing(true);
    try {
      const e0 = editCount(name);
      let backupName: string | undefined;
      // clean 本地 = 可从云重取的已知版本，无未见内容可丢 → 跳 backup（ADR-0016，不 spam .backup）。
      //   ⚠ 该论据的前提是**谱系已知**（seenBase 非 null：本地 == 云端某已知版）。!base（从未 synced /
      //   durable 双轨丢失，如 localStorage 被清而 IDB 幸存——dirty 标志会同批丢）时本地字节出身不明，
      //   「clean」不可信 → 覆盖前必 move-aside（§A：every overwrite is move-aside）。场景罕见，不构成 spam。
      if (forceBackup || head.isDirtyAnywhere(name) || localDirty() || head.seenBase(name) == null) {   // anywhere：任一 tab 有未推 → 覆盖前必 backup
        try { backupName = await local.backup(name); }
        catch (e) { reportStoreError(e, "warning"); return { ok: false, reason: "backup-failed", error: e }; }   // dirty 备份失败→中止 pull（不覆盖），degraded surface
      }
      const r = await cloud.pull(name);
      if (!r) return { ok: false, reason: "cloud-vanished", backupName };
      // 库对加密透明：先解密，validateAdopt 验的是**明文**（app 看真明文文档，不是密文容器）。
      const plain = await unseal(name, r.blob);             // 加密但锁定 → null（无密码解不开）
      // N2：坏字节（captive-portal 200-HTML / 损坏云副本）→ 拒绝，绝不覆盖唯一一份好本地（clean 没 backup）。
      //   锁定解不开 → 退验加密容器封套（captive-portal HTML 不是合法容器；无密码时能做的最强校验）。
      const ok = plain != null ? await validateAdopt(plain) : await looksEncrypted(r.blob);
      if (!ok) return { ok: false, reason: "invalid-cloud-bytes", backupName };
      const commit = async (): Promise<SafePullResult> => {
        const e1 = editCount(name);
        if (e1 !== e0) {                                      // ① 途中保存过
          if (!forceBackup) return { ok: false, reason: "edited-during-pull", backupName };
          try { backupName = await local.backup(name); }
          catch (e) { reportStoreError(e, "warning"); return { ok: false, reason: "backup-failed", backupName, error: e }; }
        }
        await local.save(name, r.blob);                       // ② 覆盖本地（存 at-rest/sealed 字节；dirty 时原件已备份）
        if (editCount(name) !== e1) return { ok: false, reason: "edited-during-pull", backupName };   // ③ 不提交谱系
        head.markSynced(name, r.item?.eTag ?? null);          // 采纳后置（R1）：etag/dirty 只在 save 成功后推进
        return { ok: true, backupName };
      };
      const done = inChain ? await commit() : await serialize(name, commit);
      if (!done.ok) return done;
      if (adopt && plain != null) await adopt(plain, name); // 复用已解密明文；锁定解不开则只快进落盘、不 adopt
      return done;
    } finally {
      onReplacing(false);
    }
  }

  // lost-response 自愈：412 可能是自己已落盘的写。拉云逐字节比对，相等即采纳（B5/W1）。
  async function tryHeal(name: string, bytes: Bytes): Promise<boolean> {
    let pulled;
    try { pulled = await cloud.pull(name); } catch (e) { reportStoreError(e, "log"); return false; }
    if (!pulled) return false;
    if (bytesEqual(await toU8(pulled.blob), bytes)) {
      head.markSynced(name, pulled.item?.eTag ?? null);     // 自愈 → 这次推等价已在云端
      return true;
    }
    return false;
  }

  // keepMine：云端→.backup，再 force-push 本地（never-lose 覆盖）。本地胜、loser 进 .backup → 落地为 synced。
  async function weakOverride(name: string, bytes: Bytes): Promise<{ backedUp: string | null; deferred?: boolean }> {
    const r = await cloud.weakOverride(name, bytes, { encrypted: await looksEncrypted(bytes) });
    // F0 红线同款 deferred guard（push.ts:73-77 的形状，2026-08-25 案卷 §4(b) 补）：provider 没回 item/eTag
    //   = 落地未确认（响应丢失/分块吞 body）。旧版无条件 markSynced(name, null)——dirty 清、etag 清、badge
    //   假 synced，且下次推 no-base fail 409。→ 不 markSynced（dirty/parent 原样保住），报 deferred；
    //   下次 push If-Match 旧 base → 若上传其实落了则 412 → tryHeal 逐字节比对自愈（组合闭环）。
    if (!(r.item && r.item.eTag)) return { backedUp: r.backedUp, deferred: true };
    head.markSynced(name, r.item.eTag);
    return { backedUp: r.backedUp, deferred: false };
  }

  // 3 选项派发（README.md §7）：takeCloud=safePull · keepMine=weakOverride · cancel=什么都不动（留 dirty）。
  async function resolveConflict(name: string, choice: ResolveChoice, ctx: { bytes?: Bytes | null; adopt?: AdoptFn; inChain?: boolean } = {}): Promise<ResolveConflictResult> {
    if (choice === "takeCloud") {
      const r = await safePull(name, { adopt: ctx.adopt, forceBackup: true, inChain: ctx.inChain });   // 换世界线 → 当前世界线无条件进 .backup（user 2026-08-25 拍板）
      return r.ok
        ? { status: "resolved", resolution: "takeCloud", backupName: r.backupName }
        : { status: "unresolved", reason: r.reason, backupName: r.backupName };
    }
    if (choice === "keepMine" && ctx.bytes != null) {
      const r = await weakOverride(name, ctx.bytes);
      if (r.deferred) return { status: "unresolved", reason: "deferred", backedUp: r.backedUp };   // 落地未确认 ≠ 已化解：dirty 保住，下次推自愈（tryHeal）
      return { status: "resolved", resolution: "keepMine", backedUp: r.backedUp };
    }
    return { status: "cancelled" };
  }

  return { safePull, tryHeal, weakOverride, resolveConflict };
}
