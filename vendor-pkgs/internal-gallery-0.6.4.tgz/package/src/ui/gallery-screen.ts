// 图库屏幕（Vue 深模块）——WET 自 WeebPaint src/gallery/gallery.ts v0.14.9（C 骑士轮「UI 深化 candidate 1」），2026-09-09 包化。
// 变化只在接缝（提案 §3「塑」）：Vue 从 deps.vue 注入；session.* 十处 → DocHost；文件动词 → core/verbs；数据 → core/data-face；
//   缩略图 / 加密 / 图标 / 文案 / 诊断 全走注入；宿主布局知识（当前夹记忆、图库模式判定）走 deps。模板与 class 名逐字保留。
import { toggleAdoptedPopup, type PopupMenuHandle } from "@internal/workbench-elements";
import type { SyncState } from "@internal/store";
import type { GItem } from "../core/model/gallery-view-model.ts";
import { tileFor, breadcrumb, asideTileFor, humanTime, humanSize, fullTime, hasLocalCopy } from "../core/model/gallery-view-model.ts";
import { ASIDE, type AsideItem, type AsideKind, type AsideScope } from "../core/model/aside.ts";
import { pathJoin } from "../core/model/gallery-path.ts";
import { imageThumbToken, imageTwinIdentifier, mimeForImageName } from "../core/model/cloud-image-model.ts";
import { createFrameGate } from "../core/guards/frame-gate.ts";
import { createFirstFrameWatchdog } from "../core/guards/first-frame-watchdog.ts";
import { note as diagNote } from "../core/guards/diag-log.ts";
import type { GalleryDataFace, GallerySnapshot, CloudImageItem } from "../core/data-face.ts";
import { createGalleryVerbs, type VerbHost, type VerbDoc, type VerbStore, type VerbEncryption } from "../core/verbs.ts";
import type { ThumbCache } from "../core/thumbs/thumb-cache.ts";
import { t } from "../core/text.ts";
import { isPng, readPngText, PNG_BLURB_KEYWORD } from "../core/thumbs/png-text.ts";

/** 宿主 vendored 的 Vue prod ESM（提案 §7.1 决定 (a)）。 */
/** 0.6.4：宿主画封面 / 占位时拿到的卡片信息（tileOverlayHtml / tilePlaceholderHtml 的第二参）。
 *  文件卡 = GItem 的字段；搁置区（回收站 / 备份箱）卡 = 从 AsideItem 映射：at → lastModified、box → aside；没有 size、没有 syncState。 */
export interface TileInfo {
  identifier: string;
  stem: string;
  /** 文档种类（store docKinds 表的 kind）；搁置区里不是文档的条目 → null。 */
  kind: string | null;
  syncState?: SyncState;
  size?: number;
  lastModified?: number;
  /** 在回收站 / 备份箱里的卡片才有。 */
  aside?: AsideKind;
}
export interface VueRuntime {
  createApp: (root: unknown) => { mount(el: HTMLElement): unknown; unmount(): void };
  /** Vue 的 Teleport 组件（0.6.2：卡片 ⋯ 菜单传送出卡片，进宿主的菜单 band；宿主把 vue 模块里的 Teleport 原样递进来）。 */
  Teleport: unknown;
  defineComponent: (o: unknown) => unknown;
  reactive: <T extends object>(o: T) => T;
  ref: <T>(v: T) => { value: T };
  computed: <T>(fn: () => T) => { value: T };
  watch: (src: () => unknown, cb: () => void) => void;
  onMounted: (fn: () => void) => void;
  onUnmounted: (fn: () => void) => void;
  nextTick: (fn?: () => void) => Promise<void>;
}
/** 图库对编辑器的全部要求（提案 §2 DocHost；WeebPaint session-state 的十处直调收成这一个端口）。 */
export interface GalleryDocHost extends VerbDoc {
  open(item: GItem): Promise<void>;
  /** 图片 tile 孪生语义（WeebPaint）：把图片字节转生成新文档；不实现 = 图片 tile 只显示不可开。 */
  importImageAsDoc?(file: File, opts: { nameOverride: string }): Promise<void>;
}
export interface GalleryEncryption extends VerbEncryption {
  isUnlocked(): boolean;
  onLockChange(cb: (unlocked: boolean) => void): void;
  isEncryptedPeekBlob(b: Blob): boolean;
  localPeekThumb(name: string): Promise<Blob | null>;
  decryptCloudPeekThumb(name: string, enc: Blob): Promise<Blob | null>;
  /** 本地字节是不是加密容器（纯本地读文件头，无网络）。 */
  isEncrypted(name: string): Promise<boolean>;
}
export interface GalleryScreenDeps {
  vue: VueRuntime;
  store: () => VerbStore | null;                 // null = 无库模式（空网格，不订阅）
  data: GalleryDataFace;
  doc: GalleryDocHost;
  host: VerbHost;
  ui: {
    iconHtml: (name: string, opts?: { size?: number; cls?: string }) => string;
    /** 0.1.2：无缩略图时卡片占位内容（HTML，通常是一枚图标）。不给 → 退回名字首字（WeebPaint 默认；WXHW 2026-09-10 user「所有的预览图都是 2……不要从名字生成」→ 宿主给 book/file 图标）。
     *  0.6.4：第二参 = 卡片信息（大小 / 修改时间 / 种类 / 在哪个箱子），可选、向后兼容。 */
    tilePlaceholderHtml?: (name: string, info?: TileInfo) => string | undefined;
    /** 0.5.0：盖在文档卡片封面上的一层宿主内容（HTML）。**有没有缩略图都画**——缩略图只是背景
     *  （WXHW 2026-09-29 user「字的逻辑一样，无视是否有图，图只是背景」）。文件 / 回收站 / 备份箱的卡片都走它；文件夹、图片、杂物卡片不走。
     *  包只给一个铺满封面、不吃指针事件的槽（`.gallery-tile-overlay`，紧跟在缩略图元素后面，宿主 CSS 可以用相邻选择器区分底下是图还是占位），
     *  里面画什么、怎么排版全归宿主；包不因为有没有这一层改变任何别的行为。列表布局不画。不给 / 返回空 = 不画。
     *  0.6.4：第二参 = 卡片信息（WXHW 2026-09-30 user「左边是 yyyymmdd，右边是 size」要在封面上印大小），可选、向后兼容。 */
    tileOverlayHtml?: (name: string, info?: TileInfo) => string | undefined;
  };
  /** 0.2.0：卡片比例。"1/1" 方图（WeebPaint 默认）；"2/3" 竖版书封（WXHW 书库；窄屏一排三本）。
   *  0.3.0（JRB 第三消费者，提案 ai-docs/20260919-proposal-list-view.md）：layout "list" = 一行一件、名字整行（最多折两行不截断）、副标题一行、右侧 ⋯；
   *  subtitle / marker = 宿主 hook（JRB：状态头 / 未读点）。全部可选，不给 = 0.2.2 行为。 */
  tile?: {
    aspect?: "1/1" | "2/3";
    layout?: "cards" | "list";
    subtitle?: (item: GItem) => string | null | undefined;
    marker?: (item: GItem) => "unread" | null | undefined;
  };
  /** 0.6.0（原 0.2.1 hasThumb）：哪几个文档种类有缩略图（docKinds 的 kind）。createGallery 从 policy.thumbs.kinds 填；空 = 都没有。
   *  没有缩略图的种类不去尾读、加密件不显锁图标（WXHW 的 txt 稿）。 */
  thumbKinds?: readonly string[];
  thumbs?: ThumbCache;
  imageThumbs?: { getOrFetch(path: string, token: string): Promise<Blob> };
  encryption?: GalleryEncryption;
  /** 「上次在哪个夹」的记忆（WeebPaint = synced collection appState.currentDirectory）；不给 = 只记内存。 */
  folderMemory?: { get(): string; set(p: string): void };
  /** 手指按住不重绘的门只在图库可见时持（WeebPaint: body[data-mode=gallery]）；不给 = 恒真。 */
  isGalleryVisible?: () => boolean;
  reportError: (err: unknown, level?: "error" | "warning" | "info" | "log") => void;
  openDiag?: () => void;
  reloadApp?: () => void;
}

/** 图库一屏能开的视图：文件 + 两个搁置区（回收站 / 备份箱，0.5.0）。 */
export type GalleryView = "files" | AsideKind;
export interface GalleryHandle {
  refresh(): void;
  setView(v: GalleryView): void;
  getView(): GalleryView;
  setFolder(path: string): void;
  hydrateFolder(path: string): void;
  getFolder(): string;
  /** 清空回收站（只清回收站，和当前开着哪个视图无关）。 */
  emptyTrash(scope?: AsideScope): void;
  /** 0.5.0：清空备份箱（只清备份箱，和当前开着哪个视图无关）。 */
  emptyBackup(scope?: AsideScope): void;
  requestUnlock(): Promise<boolean>;
  invalidateEncrypted(name: string): void;
  /** 0.3.0：布局即时切换（用户偏好记不记住归宿主）。 */
  setLayout(l: "cards" | "list"): void;
  getLayout(): "cards" | "list";
  unmount(): void;
}
interface GalleryVM {
  reload(): void; setView(v: GalleryView): void; view: GalleryView;
  setFolder(p: string): void; hydrateFolder(p: string): void; folder: string;
  emptyAside(kind: AsideKind, scope?: AsideScope): void; requestUnlock(): Promise<boolean>; invalidateEncrypted(name: string): void;
  layout: "cards" | "list"; setLayout(l: "cards" | "list"): void;
}
const PIXELATED_THUMB_MAX_EDGE = 128;
function thumbLoadPixelated(e: Event): boolean {
  const img = e.target as HTMLImageElement; const edge = Math.max(img.naturalWidth, img.naturalHeight);
  return edge > 0 && edge < PIXELATED_THUMB_MAX_EDGE;
}
export function mountGalleryScreen(el: HTMLElement, d: GalleryScreenDeps): GalleryHandle {
  const { createApp, defineComponent, reactive, ref, computed, watch, onMounted, onUnmounted, nextTick } = d.vue;
  const icon = d.ui.iconHtml;
  const phHtml = (name: string, info?: TileInfo): string => d.ui.tilePlaceholderHtml?.(name, info) ?? "";   // 0.1.2：宿主给的占位图标；空 = 退回名字首字
  const ovHtml = (name: string, info?: TileInfo): string => { try { return d.ui.tileOverlayHtml?.(name, info) ?? ""; } catch { return ""; } };   // 0.5.0：宿主盖在封面上的一层
  // 0.6.4：宿主画封面 / 占位时拿到的卡片信息。文件卡 = GItem 本尊的字段；搁置区卡从 AsideItem 映射（at → lastModified；没有 size）。
  const fileInfo = (it: GItem): TileInfo => ({ identifier: it.identifier, stem: it.stem, kind: it.kind, syncState: it.syncState, size: it.size, lastModified: it.lastModified });
  const asideInfo = (it: AsideItem): TileInfo => ({ identifier: it.identifier, stem: it.stem, kind: it.kind, lastModified: it.at || undefined, aside: it.box });
  const thumbKinds = new Set(d.thumbKinds ?? []);
  const hasThumb = (kind: string | null): boolean => kind != null && thumbKinds.has(kind);
  const ICON = {
    localOnly: icon("database"), cloudOnly: icon("cloud"), syncedBoth: icon("cloud-synced"), dirtyBoth: icon("cloud-upload"),
    float: icon("cloud-upload"), folder: icon("folder"), cloudBig: icon("cloud"),
    ghost: icon("cloud-unavailable"), pendingGone: icon("cloud-pending"), newerOnCloud: icon("cloud-download"), conflictBoth: icon("cloud-conflict"),
    lock: icon("lock"), image: icon("image"), file: icon("file"),
  };
  const enc = d.encryption;
  const _lockState = reactive({ unlocked: enc?.isUnlocked() ?? true });
  enc?.onLockChange((u) => { _lockState.unlocked = u; });
  const _thumbRev = reactive(new Map<string, number>());
  d.thumbs?.onInvalidated((key) => { _thumbRev.set(key, (_thumbRev.get(key) ?? 0) + 1); });
  const thumbKey = (identifier: string) => identifier;

  const ThumbCell = defineComponent({
    name: "ThumbCell",
    props: { encName: { type: String, default: null }, fetchable: { type: Boolean, default: false }, isCloud: { type: Boolean, default: false }, cloudNewer: { type: Boolean, default: false }, thumbToken: { type: String, default: "" }, fallback: { type: String, default: "?" }, fallbackHtml: { type: String, default: "" }, alt: { type: String, default: "" } },
    emits: ["unlock"],
    setup(props: { encName: string | null; fetchable: boolean; isCloud: boolean; cloudNewer: boolean; thumbToken: string; fallback: string; fallbackHtml: string; alt: string }) {
      const url = ref<string | null>(null), showCloud = ref(false), locked = ref(false), root = ref<HTMLElement | null>(null);
      let cloudEncBlob: Blob | null = null, objUrl: string | null = null, obs: IntersectionObserver | null = null;
      const blurb = ref("");
      // 0.2.0：缩略图 PNG 自带的 Description 文本块 = 腰封 / caption → 悬停 tooltip（user 2026-09-10「thumbnail.png 的标准 tEXt 文本块…gallery 库的公共行为」）
      const readBlurb = (blob: Blob) => { void blob.arrayBuffer().then((ab) => { const u8 = new Uint8Array(ab); blurb.value = isPng(u8) ? (readPngText(u8)[PNG_BLURB_KEYWORD] ?? "") : ""; }).catch(() => { blurb.value = ""; }); };
      const setBlob = (blob: Blob) => { if (objUrl) URL.revokeObjectURL(objUrl); objUrl = URL.createObjectURL(blob); url.value = objUrl; readBlurb(blob); };
      const tryDecrypt = async () => {
        if (!enc) { locked.value = true; return; }
        let png: Blob | null = null;
        if (props.encName) png = await enc.localPeekThumb(props.encName);
        else if (cloudEncBlob) png = await enc.decryptCloudPeekThumb(props.alt, cloudEncBlob);
        if (png && png.size > 0) { locked.value = false; setBlob(png); }
        else if (enc.isUnlocked()) locked.value = false;   // 0.2.1：解锁了但这本没封面 → 占位图标，不是锁（锁只表示「解不开」）
        else locked.value = true;
      };
      let fetchSeq = 0;
      const fetchThumb = () => {
        if (!d.thumbs) return;   // 无缩略图政策（WXHW 2.0）→ 保持占位
        const seq = ++fetchSeq;
        d.thumbs.getOrFetch(props.alt, props.thumbToken, props.cloudNewer ? "cloud" : "local")
          .then(({ blob }) => { if (seq !== fetchSeq) return; showCloud.value = false; if (!blob) return; /* 0.2.2：确定没缩略图 → 占位图标（书），不是云 */ if (enc?.isEncryptedPeekBlob(blob)) { cloudEncBlob = blob; return tryDecrypt(); } setBlob(blob); })
          .catch((err: unknown) => d.reportError(new Error("[gallery] thumb: " + String(err)), "log"));
      };
      onMounted(() => {
        if (props.encName) { void tryDecrypt(); return; }
        if (props.fetchable && d.thumbs) {
          if (props.isCloud) showCloud.value = true;
          obs = new IntersectionObserver((entries) => { for (const e of entries) { if (!e.isIntersecting) continue; obs?.disconnect(); obs = null; fetchThumb(); } }, { rootMargin: "600px 0px", threshold: 0.01 });
          void nextTick(() => { if (obs && root.value) obs.observe(root.value); });
        }
      });
      watch(() => _lockState.unlocked, () => { if (locked.value || props.encName) void tryDecrypt(); });
      watch(() => [props.thumbToken, props.cloudNewer, _thumbRev.get(thumbKey(props.alt)) ?? 0], () => {
        if (props.encName) { void tryDecrypt(); return; }
        if (!props.fetchable || obs) return;
        fetchThumb();
      });
      onUnmounted(() => { obs?.disconnect(); if (objUrl) URL.revokeObjectURL(objUrl); });
      const pixelated = ref(false);
      const onThumbLoad = (e: Event) => { pixelated.value = thumbLoadPixelated(e); };
      return { url, showCloud, locked, root, ICON, lockedTitle: t("gal.lockedThumb"), pixelated, onThumbLoad, blurb };
    },
    template: `
    <img v-if="url" class="gallery-tile-thumb" :class="{ pixelated }" :src="url" :alt="alt" :title="blurb || null" loading="lazy" @load="onThumbLoad" />
    <div v-else-if="locked" class="gallery-tile-thumb placeholder locked" :title="lockedTitle" @click.stop="$emit('unlock', encName || alt)">
      <span style="width:42px;height:42px;display:inline-block" v-html="ICON.lock"></span>
    </div>
    <div v-else class="gallery-tile-thumb placeholder" ref="root">
      <span v-if="showCloud" style="width:48px;height:48px;display:inline-block" v-html="ICON.cloudBig"></span>
      <span v-else-if="fallbackHtml" class="gallery-tile-ph-icon" v-html="fallbackHtml"></span>
      <template v-else>{{ fallback }}</template>
    </div>`,
  });

  const ImageThumbCell = defineComponent({
    name: "ImageThumbCell",
    props: { identifier: { type: String, required: true }, token: { type: String, default: "" }, fallback: { type: String, default: "?" }, alt: { type: String, default: "" } },
    setup(props: { identifier: string; token: string; fallback: string; alt: string }) {
      const url = ref<string | null>(null), root = ref<HTMLElement | null>(null);
      let objUrl: string | null = null, obs: IntersectionObserver | null = null, fetchSeq = 0;
      const fetchThumb = () => {
        if (!d.imageThumbs) return;
        const seq = ++fetchSeq;
        d.imageThumbs.getOrFetch(props.identifier, props.token)
          .then((blob) => { if (seq !== fetchSeq) return; if (objUrl) URL.revokeObjectURL(objUrl); objUrl = URL.createObjectURL(blob); url.value = objUrl; })
          .catch((err: unknown) => d.reportError(new Error("[gallery] image thumb: " + String(err)), "log"));
      };
      onMounted(() => {
        if (!d.imageThumbs) return;
        obs = new IntersectionObserver((entries) => { for (const e of entries) { if (!e.isIntersecting) continue; obs?.disconnect(); obs = null; fetchThumb(); } }, { rootMargin: "600px 0px", threshold: 0.01 });
        void nextTick(() => { if (obs && root.value) obs.observe(root.value); });
      });
      watch(() => props.token, () => { if (!obs) fetchThumb(); });
      onUnmounted(() => { obs?.disconnect(); if (objUrl) URL.revokeObjectURL(objUrl); });
      const pixelated = ref(false);
      const onThumbLoad = (e: Event) => { pixelated.value = thumbLoadPixelated(e); };
      return { url, root, pixelated, onThumbLoad };
    },
    template: `
    <img v-if="url" class="gallery-tile-thumb" :class="{ pixelated }" :src="url" :alt="alt" loading="lazy" @load="onThumbLoad" />
    <div v-else class="gallery-tile-thumb placeholder" ref="root">{{ fallback }}</div>`,
  });

  const Gallery = defineComponent({
    name: "Gallery",
    components: { ThumbCell, ImageThumbCell, Teleport: d.vue.Teleport },
    setup() {
      const view = ref<GalleryView>("files");
      const layout = ref<"cards" | "list">(d.tile?.layout ?? "cards");
      const subtitleOf = (item: GItem): string => { try { return d.tile?.subtitle?.(item) ?? ""; } catch { return ""; } };
      const markerOf = (item: GItem): "unread" | null => { try { return d.tile?.marker?.(item) ?? null; } catch { return null; } };
      const folder = ref<string>(safeFolder());
      const loading = ref(false);
      const data = reactive<{ files: GItem[]; images: CloudImageItem[]; others: GallerySnapshot["others"]; folderNames: string[] }>({ files: [], images: [], others: [], folderNames: [] });
      const aside = ref<AsideItem[]>([]);   // 当前开着的那个搁置区的列表（回收站 / 备份箱）
      const openMenu = ref<string | null>(null);
      function safeFolder() { try { return d.folderMemory?.get() || ""; } catch { return ""; } }

      let _unsub: (() => void) | null = null, _framedFolder: string | null = null, _awaitingFirst = false, _subscribedAt = 0;
      function applyFrame(snap: GallerySnapshot) {
        if (view.value !== "files" || snap.folder !== folder.value) return;
        data.files = snap.items; data.images = snap.images; data.others = snap.others; data.folderNames = snap.folderNames;
        _framedFolder = snap.folder; loading.value = false;
        wd.frame(snap.folder);
        if (stalled.value) stalled.value = null;
        if (_awaitingFirst) { _awaitingFirst = false; diagNote("gallery", `first frame folder="${snap.folder}" items=${snap.items.length} folders=${snap.folderNames.length} in ${Math.round(performance.now() - _subscribedAt)}ms`); }
        void probeEncrypted();
      }
      const gate = createFrameGate<GallerySnapshot>(applyFrame);
      const stalled = ref<string | null>(null);
      const wd = createFirstFrameWatchdog(({ folder: f, elapsedMs }) => {
        if (!loading.value) return;
        stalled.value = t("gal.firstFrameTimeout");
        const standalone = typeof matchMedia === "function" ? matchMedia("(display-mode: standalone)").matches : false;
        d.reportError(new Error(`[gallery] first frame timeout: folder="${f}" after ${elapsedMs}ms (store listing did not respond — IDB wedged?) visibility=${document.visibilityState} online=${navigator.onLine} standalone=${standalone}`), "warning");
      }, { timeoutMs: 8000 });
      function onFrameError(err: unknown, phase: "local" | "remote"): void {
        diagNote("gallery", `frame error phase=${phase} folder="${folder.value}" loading=${loading.value}: ${String(err)}`);
        if (phase === "local" && loading.value) { wd.cancel(); stalled.value = t("gal.firstFrameFailed"); }
      }
      function retry(): void { diagNote("gallery", `retry view=${view.value} folder="${folder.value}"`); stalled.value = null; _framedFolder = null; void reload(); }
      function openDiag(): void { diagNote("gallery", "open diag log from stalled grid"); d.openDiag?.(); }
      function reloadApp(): void { diagNote("gallery", `reload from stalled grid folder="${folder.value}"`); if (d.reloadApp) d.reloadApp(); else location.reload(); }
      function subscribe() {
        _unsub?.(); _unsub = null;
        if (view.value !== "files") return;
        if (!d.store()) { data.files = []; data.images = []; data.others = []; data.folderNames = []; loading.value = false; wd.cancel(); stalled.value = null; return; }   // 无库：不订阅、空网格
        loading.value = _framedFolder !== folder.value;
        stalled.value = null;
        _awaitingFirst = true; _subscribedAt = performance.now();
        if (loading.value) wd.arm(folder.value); else wd.cancel();
        diagNote("gallery", `subscribe folder="${folder.value}" loading=${loading.value}`);
        _unsub = d.data.watchFolder(folder.value, (snap) => { if (snap.folder !== folder.value) return; if (loading.value) applyFrame(snap); else gate.push(snap); }, { onError: onFrameError });
      }
      const isVisible = d.isGalleryVisible ?? (() => true);
      const _onGatePtrDown = () => { if (isVisible()) gate.pointerDown(); };
      const _onGatePtrUp = () => gate.pointerUp();
      document.addEventListener("pointerdown", _onGatePtrDown, true);
      document.addEventListener("pointerup", _onGatePtrUp, true);
      document.addEventListener("pointercancel", _onGatePtrUp, true);

      const encByName = reactive<Record<string, boolean>>({});
      async function probeEncrypted() {
        if (!enc) return;
        for (const nm of data.files.filter((it) => hasLocalCopy(it.syncState)).map((it) => it.identifier)) {
          if (nm in encByName) continue;
          try { encByName[nm] = await enc.isEncrypted(nm); } catch { encByName[nm] = false; }
        }
      }
      function invalidateEncrypted(name: string) { delete encByName[name]; void probeEncrypted(); }
      async function requestUnlock(): Promise<boolean> {
        await probeEncrypted();
        for (const it of data.files) { if (!hasLocalCopy(it.syncState) || !encByName[it.identifier]) continue; return await verbs.unlock(it.identifier); }
        return false;
      }
      // 搁置区列表：一次性读（不订阅）。序号守卫：连点切换视图时，晚到的旧结果不许盖掉新视图。
      //   读失败 = 留在「读取失败 + 重试」那一块，**不装成空列表**（空的备份箱和读不出来的备份箱不是一回事）。
      let _asideSeq = 0;
      async function loadAside(kind: AsideKind) {
        const seq = ++_asideSeq;
        wd.cancel(); stalled.value = null; aside.value = [];
        if (!d.store()) { loading.value = false; return; }   // 无库：空
        loading.value = true;
        try {
          const rows = await d.data.listAside(kind);
          if (seq !== _asideSeq || view.value !== kind) return;
          aside.value = rows; loading.value = false;
        } catch (e: unknown) {
          if (seq !== _asideSeq || view.value !== kind) return;
          diagNote("gallery", `aside listing failed kind=${kind}: ${String(e)}`);
          d.reportError(new Error(`[gallery] ${kind} listing failed: ${String((e as { message?: unknown })?.message || e)}`), "warning");
          stalled.value = t("gal.firstFrameFailed");
        }
      }
      async function reload() { closeMenu(); const v = view.value; if (v === "files") { _asideSeq++; subscribe(); } else { _unsub?.(); _unsub = null; await loadAside(v); } }
      function setFolder(p: string) { folder.value = p || ""; try { d.folderMemory?.set(folder.value); } catch { /* noop */ } closeMenu(); subscribe(); }
      function hydrateFolder(p: string) { if ((p || "") === folder.value) return; folder.value = p || ""; closeMenu(); subscribe(); }
      subscribe();
      onUnmounted(() => {
        _unsub?.(); _unsub = null; wd.cancel(); gate.reset();
        document.removeEventListener("pointerdown", _onGatePtrDown, true);
        document.removeEventListener("pointerup", _onGatePtrUp, true);
        document.removeEventListener("pointercancel", _onGatePtrUp, true);
      });

      const folderTiles = computed(() => data.folderNames.map((fn) => ({ name: fn, path: pathJoin(folder.value, fn) })));
      const fileTiles = computed(() => data.files.map((it) => { const tile = tileFor(it, { signedIn: d.host.signedIn(), activeIdentifier: d.host.activeIdentifier(), encrypted: !!encByName[it.identifier] }); return { item: it, t: tile, sub: subtitleOf(it), marker: markerOf(it), ov: ovHtml(it.identifier, fileInfo(it)), thumb: hasThumb(it.kind), info: fileInfo(it) }; }));
      // 搁置区卡片：取不取缩略图、时间后面跟哪个词，按 item 自带的 kind 查 ASIDE 表
      const asideTiles = computed(() => aside.value.map((it) => ({ item: it, t: asideTileFor(it), fetch: ASIDE[it.box].thumb === "by-name" && hasThumb(it.kind), atWord: t(ASIDE[it.box].text.at), ov: it.kind != null ? ovHtml(it.identifier, asideInfo(it)) : "", info: asideInfo(it) })));
      const imageTiles = computed(() => data.images.map((im) => ({ raw: im, identifier: im.identifier, label: im.label, size: im.size || 0, time: im.lastModified || 0, token: imageThumbToken(im) })));
      const otherTiles = computed(() => data.others.map((o) => ({ identifier: o.identifier, label: o.label, size: o.size || 0, time: o.lastModified || 0 })));
      const crumbs = computed(() => breadcrumb(folder.value));
      const isEmpty = computed(() => view.value !== "files" ? asideTiles.value.length === 0 : folderTiles.value.length === 0 && fileTiles.value.length === 0 && imageTiles.value.length === 0 && otherTiles.value.length === 0);
      const emptyText = computed(() => view.value !== "files" ? t(ASIDE[view.value].text.none) : folder.value ? t("gal.empty.folder", { f: folder.value }) : t("gal.empty.none"));
      const badgeIcon = (k: string) => (ICON as Record<string, string>)[k] || "";
      const fmtMeta = (x: { time: number; size: number }) => `${humanTime(x.time)} · ${humanSize(x.size)}`;

      // ── 卡片 ⋯ 菜单（0.6.2）：以前是卡片里的 absolute + z-index 5。卡片 :hover 带 transform，iOS 上点一下 hover 会粘住 → 卡片自成层叠上下文 →
      //   菜单的 z 只在卡片里算，后面的卡片按 DOM 顺序盖上来（WXHW 真机 2026-09-30）。任何 transform / filter / opacity / contain 出现在卡片或其祖先上都会再犯。
      //   根治 = 菜单不住卡片里：节点由 Vue <Teleport> 搬到图库挂载点（Vue 自己的 DOM 归 Vue 管，别让别人 appendChild），
      //   生命周期 / 定位 / 外点关 / Escape / 栈 / 滚动收 全交给 @internal/workbench-elements 的 popup-menu 深模块（收养 adapter：
      //   它的头注释点名「图库三 popup」就该这么走）；z 走 gallery.css 的 var(--z-menu)（band 表归宿主 :root）。
      let menuHandle: PopupMenuHandle | null = null;
      const closeMenu = () => { menuHandle?.close(); };
      const toggleMenu = (key: string, ev: Event) => {
        const btn = ev.currentTarget as HTMLElement;
        const popup = [...el.querySelectorAll<HTMLElement>(".gallery-tile-menu-popup")].find((x) => x.dataset.menu === key);
        if (!popup) return;
        const h = toggleAdoptedPopup(popup, { anchor: btn, align: "right", band: "css", position: "anchor", onClose: () => { if (menuHandle?.el === popup) { menuHandle = null; openMenu.value = null; } } });
        menuHandle = h; openMenu.value = h ? key : null;
      };
      onUnmounted(closeMenu);

      // ── 动词：core/verbs（红线兜底在那边）；这里只包 openMenu 收起 + reload ──
      const verbs = createGalleryVerbs({ store: () => { const s = d.store(); if (!s) throw new Error("gallery: no library attached"); return s; }, host: d.host, doc: d.doc, thumbs: d.thumbs, onEncryptionChanged: invalidateEncrypted, encryption: enc });
      const wrap = <A extends unknown[]>(fn: (...a: A) => Promise<void>) => async (...a: A) => { closeMenu(); await fn(...a); await reload(); };
      const rename = wrap((item: GItem) => verbs.rename(item));
      const move = wrap((item: GItem) => verbs.move(item, { folder: folder.value, folderNames: data.folderNames }));
      const copy = wrap((item: GItem) => verbs.copy(item, data.files.map((it) => it.identifier)));
      const push = wrap((item: GItem) => verbs.push(item));
      const reupload = wrap((item: GItem) => verbs.reupload(item));
      const unload = wrap((item: GItem) => verbs.unload(item));
      const keepOffline = wrap((item: GItem) => verbs.keepOffline(item));
      const del = wrap((item: GItem) => verbs.del(item));
      const deleteImage = wrap((img: CloudImageItem) => verbs.deleteImage(img));
      const folderDelete = wrap((ft: { name: string; path: string }) => verbs.folderDelete(ft));
      const asideRestore = wrap((item: AsideItem) => verbs.asideRestore(item));
      const asidePurge = wrap((item: AsideItem) => verbs.asidePurge(item));
      const emptyAside = async (kind: AsideKind, scope: AsideScope = "both") => { await verbs.emptyAside(kind, scope); await reload(); };
      const encryptItem = wrap((item: GItem) => verbs.encryptItem(item));
      const decryptItem = wrap((item: GItem) => verbs.decryptItem(item));
      async function onUnlock(name: string) { if (await verbs.unlock(name)) await reload(); }

      async function openTile(item: GItem) {
        closeMenu();
        if (item.identifier === d.host.activeIdentifier()) { await d.doc.open(item); return; }
        await d.doc.open(item); await reload();
      }
      function enterFolder(path: string) { setFolder(path); }
      async function openImageTile(img: CloudImageItem) {
        closeMenu();
        if (!d.doc.importImageAsDoc) return;   // 宿主不支持图片转生 → 图片 tile 只显示
        const st = d.store();
        const firstKind = st?.identifiers.kinds[0];
        if (!st || !firstKind) return;   // 没有文档种类 → 图片没有孪生可开
        const twin = imageTwinIdentifier(folder.value, img.label, firstKind.suffix);   // 图片转生成表里第一种文档
        const existing = data.files.find((it) => it.identifier === twin);
        if (existing) { await d.doc.open(existing); return; }
        if (await st.files.occupied(twin)) { const dd = st.identifiers.parse(twin); await d.doc.open({ identifier: twin, stem: dd?.stem ?? twin, kind: dd?.kind ?? firstKind.kind, syncState: "cloud-only" }); return; }
        try {
          const blob = await d.host.busy(t("cp.downloading", { name: img.label }), () => d.data.openCloudImage(img.identifier));
          if (!blob) { d.host.status(t("cp.downloadFailed", { name: img.label }), true); return; }
          await d.doc.importImageAsDoc(new File([blob], img.label, { type: mimeForImageName(img.label) }), { nameOverride: twin });
        } catch (e: unknown) { d.host.status(t("cp.importFailed", { err: String((e as { message?: unknown })?.message || e) }), true); }
      }

      const L = {
        activeTag: t("gal.tile.active"),
        loading: t("gal.loading"), folder: t("gal.folder"), emptyFolder: t("gal.emptyFolder"), more: t("gal.more"),
        delEmptyFolder: t("gal.delEmptyFolder"), delFolderNonEmpty: t("gal.delFolderNonEmpty"), encrypted: t("enc.locked.aria"),
        divergedNote: t("gal.divergedNote"), renameKeep: t("gal.renameKeep"), discardToTrash: t("gal.discardToTrash"),
        rename: t("gal.rename"), moveTo: t("gal.moveTo"), copy: t("gal.copy"), pullLocal: t("gal.pullLocal"),
        pushCloud: t("gal.pushCloud"), unloadLocal: t("gal.unloadLocal"), encrypt: t("menu.encrypt"), decrypt: t("menu.decrypt"),
        toTrash: t("gal.toTrash"), restore: t("gal.restore"), purge: t("gal.purge"),
        reupload: t("gal.reupload"), imageFile: t("gal.imageFile"), otherFile: t("gal.otherFile"),
        retry: t("gal.retry"), openDiag: t("gal.openDiag"), reload: t("gal.reload"),
        keepOffline: t("gal.keepOffline"), unread: t("gal.marker.unread"),
      };
      const tileTall = d.tile?.aspect === "2/3";
      return {
        tileTall, layout, setLayout: (l: "cards" | "list") => { layout.value = l; },
        view, folder, loading, stalled, retry, openDiag, reloadApp, openMenu, isEmpty, emptyText, L, phHtml,
        folderTiles, fileTiles, imageTiles, otherTiles, asideTiles, crumbs,
        badgeIcon, fmtMeta, humanTime, fullTime, ICON, toggleMenu, menuMount: el, invalidateEncrypted, setFolder, hydrateFolder, enterFolder,
        openTile, openImageTile, deleteImage, rename, move, copy, push, reupload, unload, keepOffline, del, folderDelete, asideRestore, asidePurge, emptyAside,
        encryptItem, decryptItem, onUnlock, requestUnlock, hasEncryption: !!enc,
        reload, setView: (v: GalleryView) => { view.value = v; void reload(); },
      };
    },
    template: GALLERY_TEMPLATE,
  });

  const app = createApp(Gallery);
  const vm = app.mount(el) as unknown as GalleryVM;
  return {
    refresh: () => vm.reload(), setView: (v) => vm.setView(v), getView: () => vm.view,
    setLayout: (l) => vm.setLayout(l), getLayout: () => vm.layout,
    setFolder: (p) => vm.setFolder(p), hydrateFolder: (p) => vm.hydrateFolder(p), getFolder: () => vm.folder,
    emptyTrash: (scope) => vm.emptyAside("trash", scope), emptyBackup: (scope) => vm.emptyAside("backup", scope), requestUnlock: () => vm.requestUnlock(), invalidateEncrypted: (name) => vm.invalidateEncrypted(name),
    unmount: () => app.unmount(),
  };
}

// 模板逐字自 WeebPaint gallery.ts v0.14.9（class 名不变，宿主 CSS 直接生效）；唯一增补：加密菜单项加 v-if="hasEncryption"。
const GALLERY_TEMPLATE = `
      <div class="gallery-breadcrumb" :class="{ hidden: !folder }" v-if="view==='files'">
        <template v-for="(c,i) in crumbs" :key="c.path">
          <span v-if="i>0" class="sep">›</span>
          <button type="button" :class="{ current: c.current }" @click="!c.current && setFolder(c.path)">{{ c.label }}</button>
        </template>
      </div>

      <div class="gallery-grid" :class="{ tall: tileTall, list: layout==='list' }" v-show="!isEmpty || loading">
        <div v-if="loading" class="gallery-loading">
          <template v-if="!stalled">{{ L.loading }}</template>
          <template v-else>
            <div class="gallery-stalled">{{ stalled }}</div>
            <div class="gallery-stalled-actions">
              <button type="button" class="sheet-action ghost gallery-retry-btn" @click="retry">{{ L.retry }}</button>
              <button type="button" class="sheet-action ghost" @click="openDiag">{{ L.openDiag }}</button>
              <button type="button" class="sheet-action ghost" @click="reloadApp">{{ L.reload }}</button>
            </div>
          </template>
        </div>

        <template v-if="view==='files' && !loading">
          <div v-for="ft in folderTiles" :key="'F:'+ft.path" class="gallery-tile folder" @click="enterFolder(ft.path)">
            <div class="gallery-tile-thumb" v-html="ICON.folder"></div>
            <div class="gallery-tile-name-row">
              <div class="gallery-tile-name" :title="ft.path">{{ ft.name }}</div>
              <div class="gallery-tile-meta">{{ L.folder }}</div>
            </div>
            <button type="button" class="gallery-tile-menu-btn" :aria-label="L.more" @click.stop="toggleMenu('F:'+ft.path, $event)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#more"/></svg></button>
            <Teleport :to="menuMount"><div class="gallery-tile-menu-popup hidden" :data-menu="'F:'+ft.path" @click.stop>
              <button type="button" class="danger" @click="folderDelete(ft)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.delEmptyFolder }}</span></button>
            </div></Teleport>
          </div>

          <div v-for="row in fileTiles" :key="row.t.identifier" class="gallery-tile" :class="{ active: row.t.isActive, encrypted: row.t.encrypted }" @click="openTile(row.item)">
            <ThumbCell :enc-name="row.t.encrypted && row.thumb ? row.t.identifier : null" :fetchable="!row.t.encrypted && (row.t.hasCloud || row.t.hasLocal) && row.thumb" :is-cloud="!row.t.hasLocal && row.t.hasCloud" :cloud-newer="row.t.cloudNewer" :thumb-token="String(row.t.time || row.t.size || 0)" :fallback="row.t.stem.slice(0,1) || '?'" :fallback-html="phHtml(row.t.identifier, row.info)" :alt="row.t.identifier" @unlock="onUnlock" />
            <span v-if="row.ov" class="gallery-tile-overlay" v-html="row.ov"></span>
            <span v-if="row.t.encrypted" class="gallery-tile-lockmark" :title="L.encrypted" v-html="ICON.lock"></span>
            <div class="gallery-tile-name-row">
              <span v-if="row.t.isActive" class="gallery-tile-active-tag">{{ L.activeTag }}</span>
              <div class="gallery-tile-name" :title="row.t.identifier"><span v-if="row.marker==='unread'" class="gallery-marker unread" :title="L.unread"></span>{{ row.t.stem }}</div>
              <div v-if="row.sub" class="gallery-tile-sub" :title="row.sub">{{ row.sub }}</div>
              <div class="gallery-tile-meta">
                <span v-if="row.t.encrypted" class="gallery-tile-state-icon enc" :title="L.encrypted" v-html="ICON.lock"></span>
                <span :class="'gallery-tile-state-icon b-' + row.t.badge" :title="row.t.badgeTitle" v-html="badgeIcon(row.t.badge)"></span>
                <span>{{ fmtMeta(row.t) }}</span>
              </div>
            </div>
            <button type="button" class="gallery-tile-menu-btn" :aria-label="L.more" @click.stop="toggleMenu(row.t.identifier, $event)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#more"/></svg></button>
            <Teleport :to="menuMount"><div class="gallery-tile-menu-popup hidden" :data-menu="row.t.identifier" @click.stop>
              <template v-if="row.t.ghost">
                <div class="gallery-menu-note">{{ L.divergedNote }}</div>
                <button type="button" @click="rename(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#rename"/></svg><span>{{ L.renameKeep }}</span></button>
                <button type="button" class="danger" @click="del(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.discardToTrash }}</span></button>
              </template>
              <template v-else-if="row.t.pendingGone">
                <button type="button" @click="reupload(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#upload"/></svg><span>{{ L.reupload }}</span></button>
                <button type="button" class="danger" @click="del(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.toTrash }}</span></button>
              </template>
              <template v-else>
                <button type="button" @click="rename(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#rename"/></svg><span>{{ L.rename }}</span></button>
                <button type="button" @click="move(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#move-to-folder"/></svg><span>{{ L.moveTo }}</span></button>
                <button type="button" @click="copy(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#copy"/></svg><span>{{ L.copy }}</span></button>
                <button v-if="row.t.badge==='cloudOnly'" type="button" @click="openTile(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#download"/></svg><span>{{ L.pullLocal }}</span></button>
                <button v-if="row.t.badge==='cloudOnly'" type="button" @click="keepOffline(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#local-cache"/></svg><span>{{ L.keepOffline }}</span></button>
                <button v-if="row.t.badge==='localOnly' || row.t.badge==='float'" type="button" @click="push(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#cloud-upload"/></svg><span>{{ L.pushCloud }}</span></button>
                <button v-if="row.t.badge==='dirtyBoth' || row.t.badge==='conflictBoth'" type="button" @click="push(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#cloud-upload"/></svg><span>{{ L.pushCloud }}</span></button>
                <button v-if="row.t.hasLocal && row.t.hasCloud" type="button" @click="unload(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#unload-local-cache"/></svg><span>{{ L.unloadLocal }}</span></button>
                <button v-if="hasEncryption && row.t.hasLocal && !row.t.encrypted" type="button" @click="encryptItem(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#lock"/></svg><span>{{ L.encrypt }}</span></button>
                <button v-if="hasEncryption && row.t.hasLocal && row.t.encrypted" type="button" @click="decryptItem(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#unlock"/></svg><span>{{ L.decrypt }}</span></button>
                <button type="button" class="danger" @click="del(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.toTrash }}</span></button>
              </template>
            </div></Teleport>
          </div>

          <div v-for="im in imageTiles" :key="'I:'+im.identifier" class="gallery-tile image-file" @click="openImageTile(im.raw)">
            <ImageThumbCell :identifier="im.identifier" :token="im.token" :fallback="im.label.slice(0,1) || '?'" :alt="im.label" />
            <div class="gallery-tile-name-row">
              <div class="gallery-tile-name" :title="im.identifier">{{ im.label }}</div>
              <div class="gallery-tile-meta">
                <span class="gallery-tile-state-icon" :title="L.imageFile" v-html="ICON.image"></span>
                <span>{{ fmtMeta({ time: im.time, size: im.size }) }}</span>
              </div>
            </div>
            <button type="button" class="gallery-tile-menu-btn" :aria-label="L.more" @click.stop="toggleMenu('I:'+im.identifier, $event)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#more"/></svg></button>
            <Teleport :to="menuMount"><div class="gallery-tile-menu-popup hidden" :data-menu="'I:'+im.identifier" @click.stop>
              <button type="button" class="danger" @click="deleteImage(im.raw)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.toTrash }}</span></button>
            </div></Teleport>
          </div>
          <div v-for="ot in otherTiles" :key="'O:'+ot.identifier" class="gallery-tile other-file">
            <div class="gallery-tile-thumb" v-html="ICON.file"></div>
            <div class="gallery-tile-name-row">
              <div class="gallery-tile-name" :title="ot.identifier">{{ ot.label }}</div>
              <div class="gallery-tile-meta">
                <span class="gallery-tile-state-icon" :title="L.otherFile" v-html="ICON.file"></span>
                <span>{{ fmtMeta({ time: ot.time, size: ot.size }) }}</span>
              </div>
            </div>
          </div>
        </template>

        <template v-if="view!=='files' && !loading">
          <div v-for="row in asideTiles" :key="row.t.key" class="gallery-tile aside" :class="['aside-' + row.item.box, { encrypted: row.item.encrypted }]">
            <ThumbCell :fetchable="row.fetch" :is-cloud="row.fetch && row.item.side==='cloud'" thumb-token="0" :fallback="row.t.stem.slice(0,1) || '?'" :fallback-html="row.item.kind != null ? phHtml(row.t.identifier, row.info) : ''" :alt="row.t.identifier" />
            <span v-if="row.ov" class="gallery-tile-overlay" v-html="row.ov"></span>
            <span v-if="row.item.encrypted" class="gallery-tile-lockmark" :title="L.encrypted" v-html="ICON.lock"></span>
            <div class="gallery-tile-name-row">
              <div class="gallery-tile-name" :title="row.t.identifier">{{ row.t.stem }}</div>
              <div class="gallery-tile-meta" :title="fullTime(row.t.at)">{{ row.t.source }} · {{ humanTime(row.t.at) }} {{ row.atWord }}</div>
            </div>
            <button type="button" class="gallery-tile-menu-btn" :aria-label="L.more" @click.stop="toggleMenu('A:'+row.t.key, $event)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#more"/></svg></button>
            <Teleport :to="menuMount"><div class="gallery-tile-menu-popup hidden" :data-menu="'A:'+row.t.key" @click.stop>
              <button type="button" @click="asideRestore(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#restore-trash"/></svg><span>{{ L.restore }}</span></button>
              <button type="button" class="danger" @click="asidePurge(row.item)"><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#trash-can"/></svg><span>{{ L.purge }}</span></button>
            </div></Teleport>
          </div>
        </template>
      </div>

      <div class="gallery-empty" v-show="isEmpty && !loading">{{ emptyText }}</div>
`;
