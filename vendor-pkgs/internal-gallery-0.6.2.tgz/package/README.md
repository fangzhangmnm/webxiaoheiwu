# @internal/gallery

> created 2026-09-09 by Claude Fable 5.1 · as-of **0.6.2**（2026-09-30：卡片 ⋯ 菜单出卡片进菜单 band——`<Teleport>` 到挂载点 + `@internal/workbench-elements` 收养 adapter，`VueRuntime` 多一个必填 `Teleport`；`ai-docs/20260930-0.6.2-tile-menu-band.md`；0.6.1 = 加密件卡片左上角大锁 `.gallery-tile-lockmark`）· 此前 **0.6.0**（2026-09-29：改吃 store.identifiers，`GItem = { identifier, stem, kind }`，删 naming / isDoc / isZipDoc / hasThumb；`ai-docs/20260929-0.6.0-identifiers.md`）· 此前 **0.3.0**（2026-09-19：列表视图 `tile.layout:"list"` + subtitle/marker hook + `policy.hide` + `keepOffline`，JRB 第三消费者；提案 `ai-docs/20260919-proposal-list-view.md`）· 计划 = 家族根 `ai-docs/20260909-wxhw-2.0-long-haul-plan.md`

家族图库库：文件管理 + 多库路由 + card view / list view（0.3.0）。从 WeebPaint `src/gallery/` 与 `src/` 根上的图库器官抽出（WeebPaint 行为 = spec）。提案 .h 见 `ai-docs/20260909-proposal-api.md`。消费方收货：在自家仓根 `bash "../20260909 internal-gallery/scripts/pull-package.sh" <ver>`。
